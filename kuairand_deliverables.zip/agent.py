import json
import os
import time
import traceback
import argparse
import numpy as np

from baseline import run_fm
from data import load
from features import build_tabular_features
from models import LightGBMModel, NumpyNNModel

# detect LightGBM availability to avoid heavy failures
try:
    import lightgbm as _lgb  # type: ignore
    LGB_AVAILABLE = True
except Exception:
    LGB_AVAILABLE = False


class RunLogger:
    def __init__(self, out_dir="run_logs"):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self.path = os.path.join(out_dir, "iterations.jsonl")

    def write(self, record):
        def sanitize(o):
            if isinstance(o, dict):
                return {k: sanitize(v) for k, v in o.items()}
            if isinstance(o, list):
                return [sanitize(v) for v in o]
            if isinstance(o, tuple):
                return tuple(sanitize(v) for v in o)
            if isinstance(o, np.ndarray):
                return o.tolist()
            if isinstance(o, (np.floating, np.float32, np.float64)):
                return float(o)
            if isinstance(o, (np.integer,)):
                return int(o)
            return o

        safe = sanitize(record)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(safe, ensure_ascii=False) + "\n")


def single_iteration(splits, params, logger):
    start = time.time()
    record = {
        "timestamp": time.time(),
        "hypothesis": params.get("hypothesis", "run model"),
        "code_diff": params.get("code_diff", ""),
        "params": {k: v for k, v in params.items() if k not in ("hypothesis", "code_diff")},
        "metrics": None,
        "error": None,
    }
    try:
        model_type = params.get("model", "fm")
        if model_type == "fm":
            res = run_fm(splits, k=params.get("k", 16), lr=params.get("lr", 0.001),
                         epochs=params.get("epochs", 40), seed=params.get("seed", 0), verbose=True)
            record["metrics"] = res
        elif model_type == "lgb":
            # build tabular features
            tab = build_tabular_features(splits)
            Xtr, ytr, _ = tab['train']
            Xva, yva, uva = tab['valid']
            Xte, yte, ute = tab['test']
            try:
                lgbm = LightGBMModel(params=params.get("lgb_params", None))
                lgbm.fit(Xtr, ytr, valid=(Xva, yva), num_round=params.get("num_round", 100))
                scores_va = lgbm.predict(Xva)
                scores_te = lgbm.predict(Xte)
                # evaluate expects (users, labels, scores)
                from evaluate import evaluate
                res = {'valid': evaluate(uva, yva, scores_va),
                       'test':  evaluate(ute, yte, scores_te)}
                record["metrics"] = res
            except Exception:
                record["error"] = traceback.format_exc()
        else:
            if model_type == "nn":
                # small numpy MLP on tabular features
                tab = build_tabular_features(splits)
                Xtr, ytr, _ = tab['train']
                Xva, yva, uva = tab['valid']
                Xte, yte, ute = tab['test']
                try:
                    nn = NumpyNNModel(input_dim=Xtr.shape[1], hidden=params.get("hidden", 64), lr=params.get("lr", 1e-3))
                    nn.fit(Xtr, ytr, epochs=params.get("epochs", 10), bs=params.get("bs", 4096))
                    scores_va = nn.predict(Xva)
                    scores_te = nn.predict(Xte)
                    from evaluate import evaluate
                    res = {'valid': evaluate(uva, yva, scores_va),
                           'test':  evaluate(ute, yte, scores_te)}
                    record["metrics"] = res
                except Exception:
                    record["error"] = traceback.format_exc()
            else:
                record["error"] = f"unknown model {model_type}"
    except Exception:
        record["error"] = traceback.format_exc()
    record["duration_sec"] = time.time() - start
    logger.write(record)
    return record


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="./KuaiRand-Pure/data")
    ap.add_argument("--out_dir", default="run_logs")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=20)
    a = ap.parse_args()

    print(f"loading {a.data_dir} ...")
    splits = load(a.data_dir)
    logger = RunLogger(a.out_dir)

    # Autonomous iteration loop
    epsilon = 0.002
    N = 3
    stagnation = 0
    best = -1.0
    max_iters = 10
    iter_no = 0

    # build candidate proposals
    proposals = [
        {"model": "fm", "k": 16, "lr": 0.001, "epochs": a.epochs,
         "hypothesis": "Reproduce official FM baseline", "code_diff": "baseline"},
        {"model": "fm", "k": 32, "lr": 0.001, "epochs": a.epochs,
         "hypothesis": "Increase FM embedding dim to 32", "code_diff": "k:16->32"},
    ]

    if LGB_AVAILABLE:
        proposals.append({"model": "lgb", "num_round": 50, "hypothesis": "Tabular LightGBM with simple counts",
                          "code_diff": "add tabular features, train lgb"})
    else:
        print("LightGBM not available; skipping LGB proposals.")
           {"model": "nn", "hidden": 64, "lr": 1e-3, "epochs": 10,
            "hypothesis": "NumPy MLP on tabular features", "code_diff": "add NN MLP"},
    proposals.append({"model": "fm", "k": 32, "lr": 0.0005, "epochs": a.epochs,
         "hypothesis": "Lower LR to 0.0005 for stability", "code_diff": "lr:0.001->0.0005"})
    ]

    for prop in proposals:
        iter_no += 1
        print(f"\n=== Iteration {iter_no} | model={prop.get('model')} ===")
        rec = single_iteration(splits, prop, logger)
        val = None
        if rec.get("metrics") and rec["metrics"].get("valid"):
            val = rec["metrics"]["valid"]["primary"]
        if val is None:
            print("  iteration produced no valid metrics")
            continue
        if val > best + epsilon:
            best = val
            stagnation = 0
            print(f"  new best valid primary {best:.6f}")
        else:
            stagnation += 1
            print(f"  no significant improvement (stagnation={stagnation})")
        if stagnation >= N:
            print(f"converged by stagnation (N={N}, eps={epsilon})")
            break
        if iter_no >= max_iters:
            print("reached max iters")
            break

    print("\nDone. Logs written to", logger.path)


if __name__ == '__main__':
    main()
